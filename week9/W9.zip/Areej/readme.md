# AreejCars Retail Application - Week 9 Lab

In this lab, we extended the AreejCars Retail Application by adding a Frequently Asked Questions (FAQ) page and a Tools page that utilizes session state. Additionally, we made some visual adjustments to the application.

## Update: Footer Modification

We have updated the application by making the footer a fixed bottom, ensuring it stays at the bottom of the page for a consistent user experience.

## Features Added

1. **FAQ Page**:
   - Added a link in the navbar to the FAQ page.
   - Created a Razor view `FAQ.cshtml` with commonly asked questions and answers.
   - Styled the FAQ content using Bootstrap accordion or list group components.

2. **Session State**:
   - Configured session state services in the `Program.cs` file.
   - Added a `MySession` model to the Models folder.
   - Created two Tools action methods in the HomeController for setting, displaying, and clearing session state variables.

3. **Tools Page**:
   - Added a link in the navbar to the Tools page.
   - Developed a Razor view `Tools.cshtml` to display and manage session state variables.
   - The view allows users to display and clear the session state variables.

## Implementation Details

- We added a new `Tools` link to the navbar in the `_Layout.cshtml` file.
- Modified the `Program.cs` file to include the required session state services.
- Created a `MySession` model class to store session state variables.
- Developed two action methods in the HomeController for managing session state:
  - `Tools()` to set session variables.
  - `DisplaySessionVariables()` and `ClearSessionVariables()` to display and clear session variables, respectively.
- Created the `Tools.cshtml` view to display session state variables with input fields and buttons for interaction.

## Bootstrap Styles

We utilized Bootstrap for styling the FAQ and Tools pages, ensuring a consistent and responsive look for the content.

## Usage

- Users can access the FAQ page from the navbar, where they will find answers to frequently asked questions.
- The Tools page allows users to set, display, and clear session state variables.

## Author

- AREEJ ALRADI

Enjoy using the enhanced AreejCars Retail Application!

