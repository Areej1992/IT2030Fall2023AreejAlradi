﻿using AreejCars.Models;
using Microsoft.AspNetCore.Mvc;

namespace AreejCars.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }
        public IActionResult FAQ()
        {
            return View();
        }
        public IActionResult Tools()
        {
            // Set the session state variables
            HttpContext.Session.SetString("FirstName", "Areej");
            HttpContext.Session.SetString("LastName", "Alradi");
            HttpContext.Session.SetString("Course", "IT2030");
            HttpContext.Session.SetInt32("FavNum", 14);
            MySession model = new MySession
            {
                FirstName = "FirstName",
                LastName = "LastName",
                Course = "Course",
                FavNum = 0
            };
            return View("Tools", model);
        }

        [HttpPost]
        public IActionResult DisplaySessionVariables()
        {
            MySession model = new MySession
            {
                FirstName = HttpContext.Session.GetString("FirstName"),
                LastName = HttpContext.Session.GetString("LastName"),
                Course = HttpContext.Session.GetString("Course"),
                FavNum = HttpContext.Session.GetInt32("FavNum").GetValueOrDefault()
            };
            return View("Tools", model);
        }


        [HttpPost]
        public IActionResult ClearSessionVariables()
        {
            MySession model = new MySession
            {
                FirstName = HttpContext.Session.GetString("FirstName"),
                LastName = HttpContext.Session.GetString("LastName"),
                Course = HttpContext.Session.GetString("Course"),
                FavNum = HttpContext.Session.GetInt32("FavNum").GetValueOrDefault()
            };
            HttpContext.Session.Clear();
            return RedirectToAction("Tools",model);
        }
    }
}
