﻿namespace AreejCars.Models
{
    using System.Collections.Generic;

    public class ProductData
    {
        public static List<ProductModel> GetProducts()
        {
            var products = new List<ProductModel>
    {
        new ProductModel
        {
            ProductId = 1,
            ProductName = "Sedan X",
            ProductDescription = "A luxury sedan with advanced features.",
            ProductImage = "/images/sedan_x.jpg",
            ProductPrice = 39999.99m
        },
        new ProductModel
        {
            ProductId = 2,
            ProductName = "SUV Explorer",
            ProductDescription = "An off-road SUV for adventure enthusiasts.",
            ProductImage = "/images/suv_explorer.jpg",
            ProductPrice = 45999.99m
        },
        new ProductModel
        {
            ProductId = 3,
            ProductName = "Sports Car Z",
            ProductDescription = "A high-performance sports car for speed lovers.",
            ProductImage = "/images/sports_car_z.jpg",
            ProductPrice = 54999.99m
        },
        new ProductModel
        {
            ProductId = 4,
            ProductName = "Hybrid Eco",
            ProductDescription = "An eco-friendly hybrid car with excellent fuel efficiency.",
            ProductImage = "/images/hybrid_eco.jpg",
            ProductPrice = 32999.99m
        },
        new ProductModel
        {
            ProductId = 5,
            ProductName = "Convertible Freedom",
            ProductDescription = "A convertible car for an open-air driving experience.",
            ProductImage = "/images/convertible_freedom.jpg",
            ProductPrice = 49999.99m
        },
        new ProductModel
        {
            ProductId = 6,
            ProductName = "Truck Titan",
            ProductDescription = "A powerful truck for heavy-duty tasks.",
            ProductImage = "/images/truck_titan.jpg",
            ProductPrice = 56999.99m
        },
        new ProductModel
        {
            ProductId = 7,
            ProductName = "Electric Spark",
            ProductDescription = "An electric car that's good for the environment.",
            ProductImage = "/images/electric_spark.jpg",
            ProductPrice = 39999.99m
        },
        new ProductModel
        {
            ProductId = 8,
            ProductName = "Compact Mirage",
            ProductDescription = "A compact car for city commuting.",
            ProductImage = "/images/compact_mirage.jpg",
            ProductPrice = 26999.99m
        },
        new ProductModel
        {
            ProductId = 9,
            ProductName = "Luxury Limousine",
            ProductDescription = "A luxurious limousine for special occasions.",
            ProductImage = "/images/luxury_limousine.jpg",
            ProductPrice = 69999.99m
        },
        new ProductModel
        {
            ProductId = 10,
            ProductName = "Crossover Horizon",
            ProductDescription = "A versatile crossover for various terrains.",
            ProductImage = "/images/crossover_horizon.jpg",
            ProductPrice = 45999.99m
        }
    };

            return products;
        }

        public static ProductModel GetProduct(int id)
        {
            var products = GetProducts();
            var product = products.FirstOrDefault(p => p.ProductId == id);
            return product ?? new ProductModel();
        }
    }


}
