using System.ComponentModel.DataAnnotations;

namespace AreejCars.Models
{
    public class ContactModel
    {
        [Required]
        public string? FirstName { get; set; } // Add "?" to mark as nullable

        [Required]
        public string? LastName { get; set; } // Add "?" to mark as nullable

        [Required]
        public string? Address { get; set; } // Add "?" to mark as nullable

        [Required]
        public string? Phone { get; set; } // Add "?" to mark as nullable

        [Required]
        [EmailAddress]
        public string? Email { get; set; } // Add "?" to mark as nullable

        [Required]
        public string? Message { get; set; } // Add "?" to mark as nullable
    }
}
