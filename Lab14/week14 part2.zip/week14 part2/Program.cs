using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore; // Add this line
using AreejCars.Data;

namespace AreejCars
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                })
                .ConfigureServices((context, services) =>
                {
                    services.AddSession();

                    // Add EF Core configuration for your database context
                    services.AddDbContext<AreejCarsContext>(options =>
                        options.UseSqlServer(context.Configuration.GetConnectionString("AreejCarsContext")));
                });
    }
}
