﻿using Microsoft.EntityFrameworkCore;
using AreejCars.Models;
namespace AreejCars.Data
{
    public class AreejCarsContext : DbContext
    {
        public AreejCarsContext(DbContextOptions<AreejCarsContext> options) : base(options)
        {
        }

        public DbSet<ContactModel> ContactDb { get; set; }
        public DbSet<ProductModel> ProductDb { get; set; }
    }
}
