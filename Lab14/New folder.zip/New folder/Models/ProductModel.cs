﻿using System.ComponentModel.DataAnnotations;

namespace AreejCars.Models
{
    public class ProductModel
    {
        [Key]
        public int ProductId { get; set; }

        [Required(ErrorMessage = "Product Name is required.")]
        public string ProductName { get; set; }

        [Required(ErrorMessage = "Product Description is required.")]
        public string ProductDescription { get; set; }

        [Required(ErrorMessage = "Product Image is required.")]
        public string ProductImage { get; set; }

        [DataType(DataType.Currency)]
        public decimal ProductPrice { get; set; }
    }

}
